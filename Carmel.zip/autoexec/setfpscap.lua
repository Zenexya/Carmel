local CoreGui = game:GetService("CoreGui")
local bindable = Instance.new("BindableFunction")

function bindable.OnInvoke(response)
    if(response == "Yes") then
        setfpscap(144)
    end
end

CoreGui:SetCore("SendNotification", {
	Title = "FPS Limit",
	Text = "Would you like to raise the FPS limit to 144?",
	Duration = 5,
	Callback = bindable,
	Button1 = "Yes",
	Button2 = "No"
})