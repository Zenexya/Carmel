<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <title>Editor</title>
  <style type="text/css" media="screen">
    body {
        overflow: auto;
    }

    #editor {
        margin: 0;
        position: absolute;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
		width: 100%
		height: 100%
    }
	::-webkit-scrollbar {
  width: 10px;
    height: 10px;
}

/* Track */
::-webkit-scrollbar-track {
  background: #e3e3e3; 
}
 
/* Handle */
::-webkit-scrollbar-thumb {
  background: #505050;
}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
  background: #5e5e5e; 
}
  </style>
  <script src="ace/ace.js" type="text/javascript" charset="utf-8"></script>
  <script src="ace/ext-language_tools.js"></script>
</head>
  <body style="background-color: #25282c">
    <pre id="editor"></pre>
    <script>
        var GetText;
        var SetText;
        var ClearText;
        var SetTheme;

        ace.require("ace/ext/language_tools");
        var editor = ace.edit("editor");
        editor.setTheme("ace/theme/chaos");
        editor.session.setMode("ace/mode/lua");
        editor.setOption("enableLiveAutocompletion", true);
        editor.setOption("cursorStyle", "smooth");
        document.getElementById('editor').style.fontSize='13px';

       
        GetText = function()
        {
            return editor.getValue();
        }

        SetText = function(x)
        {
          editor.setValue(x);
          editor.session.setValue(x);
        }

        ClearText = function()
        {
          editor.setValue("");
        }

        SetTheme = function(th)
        {
          editor.setTheme("ace/theme/" + th);
        }

        document.oncontextmenu = function()
        {
          return false;
        }
    </script>
  </body>
</html>
