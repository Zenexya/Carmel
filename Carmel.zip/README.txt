Thank you for using Carmel. First of all, deleting anything (other than things in the scripts folder) might break Carmel.
If you experience any issues (such as exploit not injecting, app showing an error or Roblox FPS Unlocker showing an update message)
please report them to me (シ𝓔𝓵𝓮𝓿𝓻𝓷シ#6174) ASAP.

Thank you for your co-operation and have fun!